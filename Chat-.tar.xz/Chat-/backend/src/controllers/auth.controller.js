import User from "../models/user.model.js";
import bcrypt from "bcryptjs";
import {
  generateToken
} from "../lib/utils.js";

export const signup = async (req, res) => {
  console.log("Body :", req.body);
  const {
    fullName,
    email,
    password
  } = req.body;

  try {
    // Validate password length
    if (!password || password.length < 8) {
      return res.status(400).json({
        message: "Password must be at least 8 characters"
      });
    }
    console.log(await User.findByEmail(email))
    // Check if user already exists
    const existingUser = await User.findByEmail(email);
    console.log({
      existingUser
    });
    if (existingUser) {
      return res.status(400).json({
        message: "Email already exists"
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user (await is important!)
    const newUser = await User.create({
      fullName,
      email,
      password: hashedPassword,
      profilePic: null, // optional default
      //roles: ["user"], // optional default
    });

    if (newUser) {
      // Generate JWT/session cookie
      generateToken(newUser._id, res);

      return res.status(201).json({
        _id: newUser._id,
        fullName: newUser.fullName,
        email: newUser.email,
        profilePic: newUser.profilePic ?? null,
        //roles: newUser.roles ?? ["user"],
      });
    } else {
      return res.status(400).json({
        message: "Invalid user data"
      });
    }
  } catch (error) {
    console.error("Error in signup controller", error.message);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
};

export const login = async (req, res) => {
  const {
    email,
    password
  } = req.body;
  try {
    // Find user
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(400).json({
        message: "Invalid credentials"
      });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({
        message: "Invalid email or password"
      });
    }

    // Generate token
    generateToken(user._id, res);

    return res.json({
      _id: user._id,
      fullName: user.fullName,
      email: user.email,
      profilePic: user.profilePic ?? null,
      //roles: user.roles ?? ["user"],
    });
  } catch (error) {
    console.error("Error in login controller", error.message);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
};

export const logout = (req, res) => {
  // Clear cookie if you’re storing token in cookies
  res.clearCookie("jwt");
  return res.json({
    message: "Logged out successfully"
  });
};

// Update only profile picture
export const updateProfile = async (req, res) => {
  try {
    const userId = req.user._id; // From auth middleware

    if (!req.file) {
      return res.status(400).json({
        message: "No profile picture uploaded"
      });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({
      message: "User not found"
    });

    // Remove old profile pic if exists
    if (user.profilePic) {
      const oldPath = path.join("uploads", user.profilePic);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    }

    // Update with new profile pic
    user.profilePic = req.file.filename;
    await user.save();

    return res.status(200).json({
      _id: user._id,
      fullName: user.fullName,
      email: user.email,
      profilePic: user.profilePic,
      message: "Profile picture updated successfully",
    });
  } catch (error) {
    console.error("Error updating profile picture: ", error.message);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
};

export const checkAuth = (req, res) => {
  try {
    res.status(200).json(req.user)
  } catch(error) {
    console.error("Error in checkAuth controller: ", error.message);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
}